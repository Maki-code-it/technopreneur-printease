/* ===========================================
   FILE: JS_Files/main.js
   PrintEase Digital Printing - Main JavaScript
============================================ */

// Cart System - Using localStorage to persist cart data
let cart = JSON.parse(localStorage.getItem('printease_cart')) || [];

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    updateCartCount();
    initMobileMenu();
    initAddToCart();
    initDesignModal(); // <-- New: Initializes the Send Your Design modal
    
    // Initialize cart page if on cart.html
    if (window.location.pathname.includes('cart.html')) {
        displayCart();
        initCheckout();
    }
});

// Mobile Menu Toggle
function initMobileMenu() {
    const navToggle = document.getElementById('navToggle');
    const navMenu = document.getElementById('navMenu');
    
    if (navToggle) {
        navToggle.addEventListener('click', function() {
            navMenu.classList.toggle('active');
        });
    }
}

// Add to Cart Functionality
function initAddToCart() {
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function() {
            const productCard = this.closest('.product-card');
            
            const product = {
                id: productCard.getAttribute('data-id'),
                name: productCard.getAttribute('data-name'),
                price: parseFloat(productCard.getAttribute('data-price')),
                image: productCard.getAttribute('data-image'),
                quantity: 1
            };
            
            addToCart(product);
        });
    });
}

function addToCart(product) {
    const existingItem = cart.find(item => item.id === product.id);
    
    if (existingItem) {
        existingItem.quantity += 1;
        showNotification(`${product.name} quantity updated in cart.`, 'info');
    } else {
        cart.push(product);
        showNotification(`${product.name} added to cart!`, 'success');
    }
    
    saveCart();
    updateCartCount();
    
    // If on the cart page, update the display immediately
    if (window.location.pathname.includes('cart.html')) {
        displayCart();
    }
}

function saveCart() {
    localStorage.setItem('printease_cart', JSON.stringify(cart));
}

function updateCartCount() {
    const cartCountElement = document.getElementById('cartCount');
    const totalItems = cart.reduce((total, item) => total + item.quantity, 0);
    if (cartCountElement) {
        cartCountElement.textContent = totalItems;
    }
}

// ============================================
// CART PAGE FUNCTIONS (for cart.html)
// ============================================

function displayCart() {
    const itemsContainer = document.getElementById('cartItemsList');
    const summaryContainer = document.getElementById('cartSummary');
    const emptyMessage = document.getElementById('emptyCartMessage');

    if (!itemsContainer || !summaryContainer) return;

    itemsContainer.innerHTML = '';
    
    if (cart.length === 0) {
        emptyMessage.style.display = 'block';
        summaryContainer.style.display = 'none';
        return;
    }

    emptyMessage.style.display = 'none';
    summaryContainer.style.display = 'block';

    cart.forEach(item => {
        const itemElement = document.createElement('div');
        itemElement.className = 'cart-item';
        itemElement.innerHTML = `
            <img src="${item.image}" alt="${item.name}" class="cart-item-img">
            <div class="cart-item-details">
                <h3>${item.name}</h3>
                <p class="price">₱${item.price.toFixed(2)}</p>
                <div class="quantity-controls">
                    <button class="quantity-btn" onclick="updateQuantity('${item.id}', -1)"><i class="fas fa-minus"></i></button>
                    <span class="quantity-display">${item.quantity}</span>
                    <button class="quantity-btn" onclick="updateQuantity('${item.id}', 1)"><i class="fas fa-plus"></i></button>
                </div>
            </div>
            <div class="cart-item-total">
                <p class="total-label">Subtotal</p>
                <p class="total-price">₱${(item.price * item.quantity).toFixed(2)}</p>
            </div>
            <button class="remove-btn" onclick="removeItem('${item.id}')"><i class="fas fa-trash-alt"></i></button>
        `;
        itemsContainer.appendChild(itemElement);
    });

    updateSummary();
}

function updateQuantity(productId, change) {
    const itemIndex = cart.findIndex(item => item.id === productId);
    
    if (itemIndex > -1) {
        cart[itemIndex].quantity += change;
        
        if (cart[itemIndex].quantity <= 0) {
            removeItem(productId);
        } else {
            saveCart();
            updateCartCount();
            displayCart();
        }
    }
}

function removeItem(productId) {
    cart = cart.filter(item => item.id !== productId);
    saveCart();
    updateCartCount();
    displayCart();
}

function updateSummary() {
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const shipping = subtotal > 0 ? 50.00 : 0.00; // Example flat shipping fee
    const total = subtotal + shipping;

    document.getElementById('summarySubtotal').textContent = `₱${subtotal.toFixed(2)}`;
    document.getElementById('summaryShipping').textContent = `₱${shipping.toFixed(2)}`;
    document.getElementById('summaryTotal').textContent = `₱${total.toFixed(2)}`;
    
    const checkoutBtn = document.getElementById('checkoutBtn');
    if (checkoutBtn) {
        checkoutBtn.disabled = cart.length === 0;
    }
}

function initCheckout() {
    const checkoutBtn = document.getElementById('checkoutBtn');
    const checkoutModal = document.getElementById('checkoutModal');
    const paymentForm = document.getElementById('paymentForm');
    const successModal = document.getElementById('successModal');
    
    if (checkoutBtn) {
        checkoutBtn.addEventListener('click', function() {
            if (cart.length > 0) {
                // Display the current total in the checkout modal summary
                updateSummary(); 
                checkoutModal.classList.add('active');
            }
        });
    }

    // Modal Closing Logic (for checkout and success modals)
    document.querySelectorAll('.modal-close').forEach(closeBtn => {
        closeBtn.addEventListener('click', () => {
            closeBtn.closest('.modal').classList.remove('active');
        });
    });
    
    window.addEventListener('click', (event) => {
        if (event.target === checkoutModal) {
            checkoutModal.classList.remove('active');
        }
        if (event.target === successModal) {
            successModal.classList.remove('active');
        }
    });

    // Payment Form Submission (Simulated)
    if (paymentForm) {
        paymentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const selectedPayment = document.querySelector('input[name="paymentMethod"]:checked');
            
            if (!selectedPayment) {
                alert('Please select a payment method.');
                return;
            }
            
            // Simulate Payment Processing
            const paymentMethod = selectedPayment.value;
            console.log(`Simulating order placement with ${paymentMethod}...`);
            
            // Clear cart, show success
            cart = [];
            saveCart();
            updateCartCount();
            displayCart();
            
            checkoutModal.classList.remove('active');
            successModal.classList.add('active');
            
            // Redirect or refresh after a short delay
            setTimeout(() => {
                successModal.classList.remove('active');
                window.location.href = 'shop.html'; // Redirect to shop or index
            }, 4000);
        });
    }
}

// ============================================
// NEW: DESIGN SUBMISSION MODAL FUNCTIONS (for shop.html)
// ============================================
function initDesignModal() {
    const modal = document.getElementById('designModal');
    const openBtn = document.getElementById('openDesignModalBtn');
    const closeBtn = modal ? modal.querySelector('.close-button') : null;
    const form = document.getElementById('designForm');
    const fileInput = document.getElementById('designFile');
    const formMessage = document.getElementById('designFormMessage');

    if (!modal || !openBtn || !form) return;

    // 1. Open Modal
    openBtn.addEventListener('click', () => {
        modal.classList.add('active');
    });

    // 2. Close Modal (using close button and clicking outside)
    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            modal.classList.remove('active');
        });
    }
    window.addEventListener('click', (event) => {
        if (event.target === modal) {
            modal.classList.remove('active');
        }
    });

    // 3. File Preview Logic
    fileInput.addEventListener('change', function() {
        const file = this.files[0];
        const previewContainer = document.getElementById('filePreview');
        previewContainer.innerHTML = '';
        
        if (file) {
            // Simple file size validation (max 5MB)
            if (file.size > 5 * 1024 * 1024) {
                 showDesignFormMessage('File is too large (max 5MB). Please choose a smaller image.', 'error');
                 fileInput.value = ''; // Clear file input
                 return;
            }

            const reader = new FileReader();
            reader.onload = function(e) {
                const img = document.createElement('img');
                img.src = e.target.result;
                img.style.maxWidth = '100%';
                img.style.maxHeight = '150px';
                img.style.marginTop = '10px';
                
                const fileName = document.createElement('p');
                fileName.textContent = `File Ready: ${file.name}`;
                fileName.style.fontSize = '12px';
                fileName.style.color = '#10b981';

                previewContainer.appendChild(img);
                previewContainer.appendChild(fileName);
                formMessage.style.display = 'none'; // Clear any previous error message
            };
            reader.readAsDataURL(file);
        }
    });

    // 4. Form Submission Logic (JS only, no database)
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const itemType = document.getElementById('designItemType').value;
        const quantity = document.getElementById('designQuantity').value;
        const notes = document.getElementById('designNotes').value;
        const email = document.getElementById('designEmail').value;
        const file = document.getElementById('designFile').files[0];
        
        // Simple Validation
        if (!itemType || !quantity || !email || !file) {
            showDesignFormMessage('Please fill in all required fields and upload your design.', 'error');
            return;
        }

        // Simulate Submission Process
        showDesignFormMessage('Processing your design request...', 'info');

        // Disable submit button during processing
        const submitBtn = form.querySelector('button[type="submit"]');
        submitBtn.disabled = true;

        setTimeout(() => {
            // Log data to console (as requested, since there's no database)
            console.log('--- Custom Design Request Submission (JS Only) ---');
            console.log(`Item Type: ${itemType}`);
            console.log(`Quantity: ${quantity}`);
            console.log(`Customer Email: ${email}`);
            console.log(`Notes: ${notes}`);
            console.log(`File Uploaded (Simulated): ${file.name} (${(file.size / 1024).toFixed(2)} KB)`);
            console.log('----------------------------------------------------');

            showDesignFormMessage('Your design request has been sent! We will contact you via email soon.', 'success');
            
            // Close modal and reset form after a delay
            setTimeout(() => {
                form.reset();
                document.getElementById('filePreview').innerHTML = ''; // Clear preview
                modal.classList.remove('active');
                formMessage.style.display = 'none';
                submitBtn.disabled = false; // Re-enable button
            }, 3000);

        }, 1500);
    });

    function showDesignFormMessage(message, type) {
        formMessage.textContent = message;
        
        // Reset class to prevent stacking
        formMessage.className = 'form-message'; 
        
        // Add class for styling (assuming .form-message.success, .form-message.error, and .form-message.info styles exist)
        formMessage.classList.add(type);

        formMessage.style.display = 'block';

        // Add temporary info state style if it doesn't exist
        if (type === 'info') {
             formMessage.style.backgroundColor = '#bfdbfe';
             formMessage.style.color = '#1e3a8a';
        }
    }
}

// ============================================
// UTILITY/NOTIFICATION
// ============================================

function showNotification(message, type) {
    // Create a new notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    // Style the notification
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background-color: ${type === 'success' ? '#10b981' : '#ef4444'};
        color: white;
        padding: 15px 25px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        z-index: 3000;
        font-weight: 600;
        animation: slideIn 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    // Remove notification after 3 seconds
    setTimeout(function() {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(function() {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Add CSS animations (important for showNotification to work)
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);